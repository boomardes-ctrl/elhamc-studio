import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { INITIAL_PROJECTS, SERVICES, CASE_STUDIES, INITIAL_SITE_TEXTS } from "./src/data.ts";

async function startServer() {
  const app = express();
  const PORT = 3000;
  const dbPath = path.join(process.cwd(), "db.json");

  // Middlewares
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  // Initialize db.json if not present
  let dbData = {
    projects: INITIAL_PROJECTS,
    services: SERVICES,
    caseStudies: CASE_STUDIES,
    siteTexts: INITIAL_SITE_TEXTS,
  };

  if (fs.existsSync(dbPath)) {
    try {
      const content = fs.readFileSync(dbPath, "utf-8");
      const parsed = JSON.parse(content);
      if (parsed.projects && parsed.services) {
        dbData = parsed;
        console.log("Database successfully loaded from db.json");
      }
    } catch (err) {
      console.error("Error reading db.json, using defaults:", err);
    }
  } else {
    try {
      fs.writeFileSync(dbPath, JSON.stringify(dbData, null, 2), "utf-8");
      console.log("Database initialized with default data and saved to db.json");
    } catch (err) {
      console.error("Failed to write initial db.json:", err);
    }
  }

  // API Routes
  app.get("/api/data", (req, res) => {
    res.json(dbData);
  });

  app.post("/api/save", (req, res) => {
    try {
      const { projects, services, caseStudies, siteTexts } = req.body;
      if (projects) dbData.projects = projects;
      if (services) dbData.services = services;
      if (caseStudies) dbData.caseStudies = caseStudies;
      if (siteTexts) dbData.siteTexts = siteTexts;

      fs.writeFileSync(dbPath, JSON.stringify(dbData, null, 2), "utf-8");
      res.json({ success: true });
    } catch (err) {
      console.error("Error saving to database:", err);
      res.status(500).json({ error: "Failed to save database state" });
    }
  });

  // Vite middleware setup
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Full-stack server running on http://localhost:${PORT}`);
  });
}

startServer();
